package com.practice.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practice.model.Employee;
import com.practice.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeRepository employeeRepository;

	public EmployeeServiceImpl(@Autowired EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}

	/**
	 * This method is to get employ list
	 */
	@Override
	public List<Employee> getAllEmployeeList() {
		return employeeRepository.findAll();
	}

	/**
	 * This method is to save employee
	 */
	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	/**
	 * This method is to find the employee by id
	 */
	@Override
	public Employee findEmployeeById(long id) {

		Optional<Employee> optional = employeeRepository.findById(id);

		Employee employee = null;
		if (optional.isPresent()) {
			employee = optional.get();
		} else {
			throw new RuntimeException(" Employee not found for id :: " + id);
		}
		return employee;
	}

	/**
	 * This method is to update the employee
	 */
	@Override
	public Employee updateEmployee(Employee employee) {
		Optional<Employee> optional = employeeRepository.findById(employee.getId());

		if (!optional.isPresent()) {
			throw new RuntimeException(" Employee not found for id :: " + employee.getId());
		}

		return employeeRepository.save(employee);
	}

}
