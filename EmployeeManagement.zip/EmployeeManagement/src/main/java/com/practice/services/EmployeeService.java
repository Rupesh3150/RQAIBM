package com.practice.services;

import java.util.List;

import com.practice.model.Employee;

public interface EmployeeService {
	
	List<Employee> getAllEmployeeList();
	
	Employee saveEmployee(Employee employee);
	
	Employee findEmployeeById(long id);
	
	Employee updateEmployee(Employee employee);
	
}
