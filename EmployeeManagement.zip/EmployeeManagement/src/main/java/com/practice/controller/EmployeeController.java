
package com.practice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.practice.model.Employee;
import com.practice.services.EmployeeService;

@RestController
public class EmployeeController {

	Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	private EmployeeService employeeService;

	public EmployeeController(@Autowired EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	/**
	 * This method is for getting the employee list
	 * 
	 * @return List of Employee List
	 */
	@GetMapping(value = "/employees", produces = { "application/json" })
	public List<Employee> getEmployees() {

		logger.info("In the start of getEmployees method");

		List<Employee> list = employeeService.getAllEmployeeList();

		logger.debug("Response Body : {}", list);
		logger.info("At the end of getEmployees method");

		return list;
	}

	/**
	 * This method is for saving the Employee
	 * 
	 * @param employee
	 * @return
	 */
	@PostMapping(value = "/saveEmployee", produces = { "application/json" })
	public Employee saveEmployee(@RequestBody Employee employee) {

		logger.info("In the start of saveEmployee method");
		logger.debug("Request Body : {}", employee);

		Employee emp = employeeService.saveEmployee(employee);
		logger.debug("Response Body : {}", emp);

		logger.info("At the end of saveEmployee method");

		return emp;
	}

	/**
	 * This method is to update the Employee
	 * 
	 * @param employee
	 * @return
	 */
	@PutMapping(value = "/updateEmployee", produces = { "application/json" })
	public Employee updateEmployee(@RequestBody Employee employee) {

		logger.info("At the start of updateEmployee method");
		logger.debug("Request Body : {}", employee);

		Employee emp = employeeService.updateEmployee(employee);

		logger.debug("Response Body : {}", emp);
		logger.info("At the end of updateEmployee method");

		return emp;
	}

	/**
	 * This method is to get the employee based on id
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping(value = "/employee/{empid}", produces = { "application/json" })
	public Employee getEmployee(@PathVariable("empid") Integer id) {

		logger.info("At the start of getEmployee method");
		logger.debug("Employee Id : {}", id);

		Employee emp = employeeService.findEmployeeById(id);

		logger.debug("Response Body : {}", emp);
		logger.info("At the end of getEmployee method");

		return emp;
	}

}
