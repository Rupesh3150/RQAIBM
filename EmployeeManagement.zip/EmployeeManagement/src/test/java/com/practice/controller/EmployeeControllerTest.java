package com.practice.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.google.gson.Gson;
import com.practice.model.Employee;
import com.practice.services.EmployeeService;

@RunWith(SpringRunner.class)
@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmployeeService employeeService;

	@Test
	public void getEmployeesTest() throws Exception {

		mockMvc.perform(get("/employees").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	public void getEmployeeTest() throws Exception {

		mockMvc.perform(get("/employees").param("empid", "23").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}

	@Test
	public void saveEmployeeTest() throws Exception {

		Gson gson=new Gson();
		Employee emp=new Employee();
		emp.setFirstName("Ramesh");
		emp.setLastName("yadav");
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/saveEmployee").accept(MediaType.APPLICATION_JSON)
				.content(gson.toJson(emp)).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		
	}

	
	@Test
	public void updateEmployeeTest() throws Exception {

		Gson gson=new Gson();
		Employee emp=new Employee();
		emp.setFirstName("Ramesh");
		emp.setLastName("yadav");
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/updateEmployee").accept(MediaType.APPLICATION_JSON)
				.content(gson.toJson(emp)).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());

	}

	

	
	

}
